<div class="row g-3">
    <!-- Welcome Card -->
    <div class="col-12">
        <div class="card-mobile p-3 bg-white">
            <div class="d-flex align-items-center">
                <div class="avatar-mobile me-3 bg-soft-primary text-primary">
                    <i class="bi bi-person-fill fs-4"></i>
                </div>
                <div>
                    <h6 class="mb-0 fw-bold">Welcome, <?php echo $_SESSION['username']; ?></h6>
                    <small class="text-muted">Teacher | Next Class: Math (10:30)</small>
                </div>
            </div>
        </div>
    </div>

    <!-- Stats Row -->
    <div class="col-6">
        <div class="card-mobile p-3 text-center bg-white">
            <h4 class="mb-0 fw-bold text-primary">95%</h4>
            <small class="text-muted">Attendance</small>
        </div>
    </div>
    <div class="col-6">
        <div class="card-mobile p-3 text-center bg-white">
            <h4 class="mb-0 fw-bold text-success">12</h4>
            <small class="text-muted">Assignments</small>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="col-12">
        <h6 class="fw-bold mb-3">Quick Actions</h6>
        <div class="row g-2">
            <div class="col-6">
                <a href="<?php echo BASE_URL; ?>iteacher/attendance" class="card-mobile p-3 text-center bg-white text-decoration-none d-block">
                    <i class="bi bi-check2-square fs-3 text-info"></i>
                    <div class="small fw-bold mt-1">Mark Attendance</div>
                </a>
            </div>
            <div class="col-6">
                <a href="<?php echo BASE_URL; ?>iteacher/behavior" class="card-mobile p-3 text-center bg-white text-decoration-none d-block">
                    <i class="bi bi-megaphone fs-3 text-warning"></i>
                    <div class="small fw-bold mt-1">Record Incident</div>
                </a>
            </div>
        </div>
    </div>

    <!-- Today's Schedule -->
    <div class="col-12">
        <div class="card-mobile p-0 overflow-hidden bg-white">
            <div class="p-3 border-bottom">
                <h6 class="mb-0 fw-bold">Today's Schedule</h6>
            </div>
            <div class="list-group list-group-flush">
                <div class="list-group-item d-flex justify-content-between align-items-center">
                    <div>
                        <div class="fw-bold">Mathematics</div>
                        <small class="text-muted">Grade 10A | 08:30 - 09:30</small>
                    </div>
                    <span class="badge bg-soft-success text-success">Ended</span>
                </div>
                <div class="list-group-item d-flex justify-content-between align-items-center bg-light">
                    <div>
                        <div class="fw-bold">Physics</div>
                        <small class="text-muted">Grade 11B | 10:30 - 11:30</small>
                    </div>
                    <span class="badge bg-primary">Upcoming</span>
                </div>
            </div>
        </div>
    </div>
</div>

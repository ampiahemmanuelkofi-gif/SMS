

<div class="row mb-4">
    <div class="col-md-12">
        <h2 class="page-title"><i class="bi bi-graph-up"></i> Attendance Analytics</h2>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="alert alert-info">
            <i class="bi bi-info-circle"></i> Detailed analytics and charts are under development. Please check the <a href="<?php echo BASE_URL; ?>attendance/reports" class="alert-link">Reports</a> page for current data.
        </div>
    </div>
</div>

<footer class="footer mt-auto py-4 bg-white border-top">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted">
                Copyright &copy; <?php echo SCHOOL_NAME; ?> <?php echo date('Y'); ?>
            </div>
            <div>
                <a href="#" class="text-muted text-decoration-none me-3">Privacy Policy</a>
                <a href="#" class="text-muted text-decoration-none me-3">Terms & Conditions</a>
                <span class="text-muted pe-1">Powered by</span>
                <a href="https://eamp-systems.com" class="fw-bold text-primary text-decoration-none">EAMP School Pro v2.5</a>
            </div>
        </div>
    </div>
</footer>

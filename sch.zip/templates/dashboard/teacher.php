<div class="row mb-4">
    <div class="col-md-12">
        <div class="alert alert-primary">
            <i class="bi bi-person-circle"></i>
            <strong>Welcome, <?php echo Auth::getFullName(); ?>!</strong> Here's an overview of your classes and assignments.
        </div>
    </div>
</div>

<div class="row mb-4">
    <!-- Assigned Classes -->
    <div class="col-md-8 mb-4">
        <div class="table-card">
            <h5 class="mb-3"><i class="bi bi-book-fill"></i> My Assigned Classes</h5>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Class</th>
                            <th>Section</th>
                            <th>Level</th>
                            <th>Students</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($assignedClasses)): ?>
                            <?php foreach ($assignedClasses as $class): ?>
                                <tr>
                                    <td><?php echo Security::clean($class['class_name']); ?></td>
                                    <td><?php echo Security::clean($class['section_name']); ?></td>
                                    <td><span class="badge bg-info"><?php echo ucfirst($class['level']); ?></span></td>
                                    <td><?php echo $class['student_count']; ?></td>
                                    <td>
                                        <a href="<?php echo BASE_URL; ?>attendance/mark/<?php echo $class['id']; ?>" 
                                           class="btn btn-sm btn-success" title="Mark Attendance">
                                            <i class="bi bi-calendar-check-fill"></i>
                                        </a>
                                        <a href="<?php echo BASE_URL; ?>assessments/entry/<?php echo $class['id']; ?>" 
                                           class="btn btn-sm btn-primary" title="Enter Marks">
                                            <i class="bi bi-clipboard-data-fill"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center text-muted">No classes assigned yet</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Quick Stats -->
    <div class="col-md-4 mb-4">
        <div class="stat-card mb-3">
            <div class="icon" style="background: linear-gradient(135deg, #667eea, #764ba2); color: white;">
                <i class="bi bi-people-fill"></i>
            </div>
            <h3><?php echo count($assignedClasses); ?></h3>
            <p>Assigned Classes</p>
        </div>
        
        <div class="stat-card">
            <div class="icon" style="background: linear-gradient(135deg, #f093fb, #f5576c); color: white;">
                <i class="bi bi-clipboard-x-fill"></i>
            </div>
            <h3><?php echo $pendingMarks; ?></h3>
            <p>Pending Marks Entry</p>
        </div>
    </div>
</div>

<div class="row">
    <!-- Recent Homework -->
    <div class="col-md-12 mb-4">
        <div class="table-card">
            <h5 class="mb-3"><i class="bi bi-journal-text"></i> Recent Homework Assignments</h5>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Subject</th>
                            <th>Class</th>
                            <th>Due Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($homework)): ?>
                            <?php foreach ($homework as $hw): ?>
                                <tr>
                                    <td><?php echo Security::clean($hw['title']); ?></td>
                                    <td><?php echo Security::clean($hw['subject_name']); ?></td>
                                    <td><?php echo Security::clean($hw['class_name'] . ' ' . $hw['section_name']); ?></td>
                                    <td><?php echo date('M d, Y', strtotime($hw['due_date'])); ?></td>
                                    <td>
                                        <?php
                                        $dueDate = strtotime($hw['due_date']);
                                        $today = strtotime(date('Y-m-d'));
                                        if ($dueDate < $today) {
                                            echo '<span class="badge bg-danger">Overdue</span>';
                                        } elseif ($dueDate == $today) {
                                            echo '<span class="badge bg-warning">Due Today</span>';
                                        } else {
                                            echo '<span class="badge bg-success">Active</span>';
                                        }
                                        ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center text-muted">No homework assignments yet</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <a href="<?php echo BASE_URL; ?>homework/create" class="btn btn-sm btn-primary">
                <i class="bi bi-plus-circle-fill"></i> Add New Homework
            </a>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="row">
    <div class="col-md-12">
        <div class="table-card">
            <h5 class="mb-3"><i class="bi bi-lightning-fill"></i> Quick Actions</h5>
            <div class="d-flex gap-2 flex-wrap">
                <a href="<?php echo BASE_URL; ?>attendance/mark" class="btn btn-success">
                    <i class="bi bi-calendar-check-fill"></i> Mark Attendance
                </a>
                <a href="<?php echo BASE_URL; ?>assessments/entry" class="btn btn-primary">
                    <i class="bi bi-clipboard-data-fill"></i> Enter Marks
                </a>
                <a href="<?php echo BASE_URL; ?>homework/create" class="btn btn-info text-white">
                    <i class="bi bi-journal-plus"></i> Add Homework
                </a>
                <a href="<?php echo BASE_URL; ?>reports/class" class="btn btn-secondary">
                    <i class="bi bi-file-earmark-pdf-fill"></i> Class Reports
                </a>
            </div>
        </div>
    </div>
</div>

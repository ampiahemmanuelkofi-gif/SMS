<div class="row mb-4">
    <!-- Fee Collection Statistics -->
    <div class="col-md-4 mb-3">
        <div class="stat-card">
            <div class="icon" style="background: linear-gradient(135deg, #43e97b, #38f9d7); color: white;">
                <i class="bi bi-cash-coin"></i>
            </div>
            <h3>GH₵ <?php echo number_format($stats['total_collected'], 2); ?></h3>
            <p>Total Collected (<?php echo $currentTerm['name']; ?>)</p>
        </div>
    </div>
    
    <div class="col-md-4 mb-3">
        <div class="stat-card">
            <div class="icon" style="background: linear-gradient(135deg, #667eea, #764ba2); color: white;">
                <i class="bi bi-wallet2"></i>
            </div>
            <h3>GH₵ <?php echo number_format($stats['total_expected'], 2); ?></h3>
            <p>Total Expected</p>
        </div>
    </div>
    
    <div class="col-md-4 mb-3">
        <div class="stat-card">
            <div class="icon" style="background: linear-gradient(135deg, #f093fb, #f5576c); color: white;">
                <i class="bi bi-exclamation-triangle-fill"></i>
            </div>
            <h3>GH₵ <?php echo number_format($stats['total_pending'], 2); ?></h3>
            <p>Total Pending</p>
        </div>
    </div>
</div>

<div class="row mb-4">
    <div class="col-md-12">
        <div class="alert alert-info">
            <i class="bi bi-info-circle-fill"></i>
            <strong>Collection Rate:</strong> 
            <?php 
            $collectionRate = $stats['total_expected'] > 0 
                ? round(($stats['total_collected'] / $stats['total_expected']) * 100, 1) 
                : 0;
            echo $collectionRate . '%';
            ?>
            | <strong>Payments Today:</strong> <?php echo $stats['payments_today']; ?>
        </div>
    </div>
</div>

<div class="row">
    <!-- Recent Payments -->
    <div class="col-md-12 mb-4">
        <div class="table-card">
            <h5 class="mb-3"><i class="bi bi-receipt"></i> Recent Fee Payments</h5>
            <div class="table-responsive">
                <table class="table table-hover data-table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Student ID</th>
                            <th>Student Name</th>
                            <th>Amount</th>
                            <th>Method</th>
                            <th>Reference</th>
                            <th>Received By</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($recentPayments)): ?>
                            <?php foreach ($recentPayments as $payment): ?>
                                <tr>
                                    <td><?php echo date('M d, Y', strtotime($payment['payment_date'])); ?></td>
                                    <td><?php echo Security::clean($payment['student_id']); ?></td>
                                    <td><?php echo Security::clean($payment['first_name'] . ' ' . $payment['last_name']); ?></td>
                                    <td><strong>GH₵ <?php echo number_format($payment['amount'], 2); ?></strong></td>
                                    <td>
                                        <span class="badge bg-primary">
                                            <?php echo ucfirst(str_replace('_', ' ', $payment['payment_method'])); ?>
                                        </span>
                                    </td>
                                    <td><?php echo Security::clean($payment['reference_number']); ?></td>
                                    <td><?php echo Security::clean($payment['received_by_name']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center text-muted">No payments recorded yet</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="row">
    <div class="col-md-12">
        <div class="table-card">
            <h5 class="mb-3"><i class="bi bi-lightning-fill"></i> Quick Actions</h5>
            <div class="d-flex gap-2 flex-wrap">
                <a href="<?php echo BASE_URL; ?>fees/payment" class="btn btn-primary">
                    <i class="bi bi-cash-stack"></i> Record Payment
                </a>
                <a href="<?php echo BASE_URL; ?>fees/balances" class="btn btn-warning">
                    <i class="bi bi-wallet2"></i> View Balances
                </a>
                <a href="<?php echo BASE_URL; ?>fees/structure" class="btn btn-info text-white">
                    <i class="bi bi-list-ul"></i> Fee Structure
                </a>
                <a href="<?php echo BASE_URL; ?>reports/fees" class="btn btn-secondary">
                    <i class="bi bi-file-earmark-pdf-fill"></i> Fee Reports
                </a>
            </div>
        </div>
    </div>
</div>

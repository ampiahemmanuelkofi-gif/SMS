<div class="row mb-4">
    <div class="col-md-12">
        <div class="alert alert-primary">
            <i class="bi bi-person-hearts"></i>
            <strong>Welcome, <?php echo Auth::getFullName(); ?>!</strong> Here's an overview of your children's academic progress.
        </div>
    </div>
</div>

<div class="row">
    <?php if (!empty($children)): ?>
        <?php foreach ($children as $child): ?>
            <div class="col-md-6 mb-4">
                <div class="table-card">
                    <div class="d-flex align-items-center mb-3">
                        <div class="user-avatar me-3" style="width: 60px; height: 60px; font-size: 24px;">
                            <?php echo strtoupper(substr($child['first_name'], 0, 1)); ?>
                        </div>
                        <div>
                            <h5 class="mb-0"><?php echo Security::clean($child['first_name'] . ' ' . $child['last_name']); ?></h5>
                            <p class="mb-0 text-muted">
                                <?php echo Security::clean($child['student_id']); ?> | 
                                <?php echo Security::clean($child['class_name'] . ' ' . $child['section_name']); ?>
                            </p>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-6">
                            <div class="stat-card" style="padding: 15px;">
                                <div class="icon" style="width: 40px; height: 40px; font-size: 20px; background: linear-gradient(135deg, #43e97b, #38f9d7); color: white;">
                                    <i class="bi bi-calendar-check-fill"></i>
                                </div>
                                <h4 class="mt-2"><?php echo $child['attendance_percentage']; ?>%</h4>
                                <p class="mb-0 small">Attendance</p>
                            </div>
                        </div>
                        
                        <div class="col-6">
                            <div class="stat-card" style="padding: 15px;">
                                <div class="icon" style="width: 40px; height: 40px; font-size: 20px; background: linear-gradient(135deg, #f093fb, #f5576c); color: white;">
                                    <i class="bi bi-wallet2"></i>
                                </div>
                                <h4 class="mt-2">GH₵ <?php echo number_format($child['fee_balance'], 2); ?></h4>
                                <p class="mb-0 small">Fee Balance</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mt-3 d-flex gap-2">
                        <a href="<?php echo BASE_URL; ?>parent/attendance/<?php echo $child['id']; ?>" 
                           class="btn btn-sm btn-primary flex-fill">
                            <i class="bi bi-calendar-check-fill"></i> View Attendance
                        </a>
                        <a href="<?php echo BASE_URL; ?>parent/marks/<?php echo $child['id']; ?>" 
                           class="btn btn-sm btn-success flex-fill">
                            <i class="bi bi-clipboard-data-fill"></i> View Marks
                        </a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div class="col-md-12">
            <div class="alert alert-warning">
                <i class="bi bi-exclamation-triangle-fill"></i>
                No children linked to your account. Please contact the school administrator.
            </div>
        </div>
    <?php endif; ?>
</div>

<!-- Notices -->
<div class="row">
    <div class="col-md-12 mb-4">
        <div class="table-card">
            <h5 class="mb-3"><i class="bi bi-megaphone-fill"></i> School Notices</h5>
            <div class="list-group list-group-flush">
                <?php if (!empty($notices)): ?>
                    <?php foreach ($notices as $notice): ?>
                        <div class="list-group-item">
                            <div class="d-flex w-100 justify-content-between">
                                <h6 class="mb-1"><?php echo Security::clean($notice['title']); ?></h6>
                                <small><?php echo date('M d, Y', strtotime($notice['created_at'])); ?></small>
                            </div>
                            <p class="mb-0"><?php echo Security::clean($notice['content']); ?></p>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="list-group-item text-center text-muted">No notices available</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="row g-3">
    <!-- Student Profile Header -->
    <div class="col-12">
        <div class="card-mobile p-3 bg-primary text-white">
            <div class="d-flex align-items-center">
                <div class="avatar-mobile me-3 bg-white text-primary">
                    <i class="bi bi-person-fill fs-4"></i>
                </div>
                <div>
                    <h6 class="mb-0 fw-bold"><?php echo $student['first_name'] . ' ' . $student['last_name']; ?></h6>
                    <small class="opacity-75"><?php echo $student['class_name']; ?> | ID: <?php echo $student['student_id']; ?></small>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Links -->
    <div class="col-4 text-center">
        <a href="<?php echo BASE_URL; ?>istudent/timetable" class="text-decoration-none">
            <div class="card-mobile p-3 bg-white mb-1">
                <i class="bi bi-calendar3 fs-4 text-primary"></i>
            </div>
            <small class="text-dark">Timetable</small>
        </a>
    </div>
    <div class="col-4 text-center">
        <a href="<?php echo BASE_URL; ?>istudent/assignments" class="text-decoration-none">
            <div class="card-mobile p-3 bg-white mb-1">
                <i class="bi bi-book fs-4 text-success"></i>
            </div>
            <small class="text-dark">Homework</small>
        </a>
    </div>
    <div class="col-4 text-center">
        <a href="#" class="text-decoration-none">
            <div class="card-mobile p-3 bg-white mb-1">
                <i class="bi bi-award fs-4 text-warning"></i>
            </div>
            <small class="text-dark">Results</small>
        </a>
    </div>

    <!-- Current Class Alert -->
    <div class="col-12">
        <div class="card-mobile p-3 bg-soft-info border-start border-4 border-info">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <small class="fw-bold text-info text-uppercase">Now Playing</small>
                <span class="badge bg-info">Period 4</span>
            </div>
            <h5 class="fw-bold mb-1">Mathematics</h5>
            <div class="small"><i class="bi bi-geo-alt-fill"></i> Lab C | <i class="bi bi-person-fill text-muted"></i> Mr. Smith</div>
        </div>
    </div>

    <!-- Assignments Tracker -->
    <div class="col-12">
        <h6 class="fw-bold mb-3">Pending Homework</h6>
        <div class="card-mobile bg-white p-0 overflow-hidden">
            <div class="p-3 border-bottom d-flex align-items-center">
                <div class="form-check me-3">
                    <input class="form-check-input" type="checkbox">
                </div>
                <div class="flex-grow-1">
                    <h6 class="mb-0 fw-bold">Physics: Wave Motion Exercises</h6>
                    <small class="text-danger">Due: Today, 4:00 PM</small>
                </div>
            </div>
            <div class="p-3 d-flex align-items-center">
                <div class="form-check me-3">
                    <input class="form-check-input" type="checkbox">
                </div>
                <div class="flex-grow-1">
                    <h6 class="mb-0 fw-bold">History: Essay on Industrial Revolution</h6>
                    <small class="text-muted">Due: Tomorrow</small>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .bg-soft-info { background-color: #e0f2f7; }
</style>

<div class="row g-3">
    <!-- Child Selector -->
    <div class="col-12">
        <div class="card-mobile p-3 bg-white">
            <label class="form-label small fw-bold">Active Child</label>
            <div class="d-flex align-items-center">
                <div class="avatar-mobile me-3 bg-soft-info text-info">
                    <i class="bi bi-person-fill fs-4"></i>
                </div>
                <div class="flex-grow-1">
                    <h6 class="mb-0 fw-bold"><?php echo $selectedChild['first_name'] . ' ' . $selectedChild['last_name']; ?></h6>
                    <small class="text-muted"><?php echo $selectedChild['class_name'] . ' | ' . $selectedChild['section_name']; ?></small>
                </div>
                <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#childModal">
                    Switch
                </button>
            </div>
        </div>
    </div>

    <!-- Quick Stats for Parent -->
    <div class="col-6">
        <div class="card-mobile p-3 text-center bg-white border-bottom border-4 border-success">
            <h4 class="mb-0 fw-bold">98%</h4>
            <small class="text-muted">Attendance</small>
        </div>
    </div>
    <div class="col-6">
        <div class="card-mobile p-3 text-center bg-white border-bottom border-4 border-primary">
            <h4 class="mb-0 fw-bold">A-</h4>
            <small class="text-muted">Avg Grade</small>
        </div>
    </div>

    <!-- News Feed -->
    <div class="col-12">
        <h6 class="fw-bold mb-3">School News Feed</h6>
        <div class="card-mobile bg-white p-0 overflow-hidden">
            <div class="p-3 border-bottom">
                <div class="d-flex justify-content-between">
                    <span class="badge bg-soft-warning text-warning mb-2">Event</span>
                    <small class="text-muted">2h ago</small>
                </div>
                <h6 class="fw-bold mb-1">Annual Sports Day 2026</h6>
                <p class="small text-muted mb-0">Join us this Friday for our annual sports meet at the main stadium...</p>
            </div>
            <div class="p-3">
                <div class="d-flex justify-content-between">
                    <span class="badge bg-soft-info text-info mb-2">Announcement</span>
                    <small class="text-muted">Yesterday</small>
                </div>
                <h6 class="fw-bold mb-1">Term 2 Examination Schedule</h6>
                <p class="small text-muted mb-0">The examination schedule for Term 2 has been published in the Documents section.</p>
            </div>
        </div>
    </div>
</div>

<!-- Child Switching Modal -->
<div class="modal fade" id="childModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 card-mobile">
            <div class="modal-header border-0">
                <h6 class="modal-title fw-bold">Switch Child</h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body pt-0">
                <div class="list-group list-group-flush">
                    <?php foreach ($children as $child): ?>
                    <a href="?switch_child=<?php echo $child['id']; ?>" class="list-group-item list-group-item-action d-flex align-items-center py-3">
                        <div class="avatar-mobile small me-3 <?php echo ($child['id'] == $selectedChild['id']) ? 'bg-primary text-white' : 'bg-light'; ?>">
                            <i class="bi bi-person"></i>
                        </div>
                        <div class="flex-grow-1">
                            <div class="fw-bold"><?php echo $child['first_name']; ?></div>
                            <small class="text-muted"><?php echo $child['class_name']; ?></small>
                        </div>
                        <?php if ($child['id'] == $selectedChild['id']): ?>
                            <i class="bi bi-check-circle-fill text-primary"></i>
                        <?php endif; ?>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
/**
 * Fee Model
 */

class FeesModel extends Model {
    
    public function getFeeCategories() {
        return $this->select("SELECT * FROM fee_categories ORDER BY name");
    }
    
    public function getCurrencies() {
        return $this->select("SELECT * FROM currencies ORDER BY is_base DESC, code");
    }
    
    /**
     * Generate Invoices for all active students in a term
     */
    public function generateInvoices($termId) {
        $db = getDbConnection();
        $students = $db->query("SELECT s.id, s.section_id, sec.class_id FROM students s JOIN sections sec ON s.section_id = sec.id WHERE s.status = 'active'")->fetchAll();
        
        $count = 0;
        foreach ($students as $student) {
            // Check if invoice already exists
            $check = $db->query("SELECT id FROM fee_invoices WHERE student_id = {$student['id']} AND term_id = $termId")->fetch();
            if ($check) continue;
            
            // Get applicable fees for this class and term
            $fees = $db->query("SELECT id, amount, category_id, description FROM fee_structure WHERE class_id = {$student['class_id']} AND term_id = $termId")->fetchAll();
            if (empty($fees)) continue;
            
            $totalAmount = array_sum(array_column($fees, 'amount'));
            $invoiceNumber = 'INV-' . date('Ymd') . '-' . str_pad($student['id'], 4, '0', STR_PAD_LEFT);
            
            $stmt = $db->prepare("INSERT INTO fee_invoices (invoice_number, student_id, term_id, total_amount, status, due_date) VALUES (?, ?, ?, ?, 'unpaid', ?)");
            $stmt->execute([$invoiceNumber, $student['id'], $termId, $totalAmount, date('Y-m-t')]); // Due end of month
            $invoiceId = $db->lastInsertId();
            
            // Add items
            $itemStmt = $db->prepare("INSERT INTO invoice_items (invoice_id, category_id, amount, description) VALUES (?, ?, ?, ?)");
            foreach ($fees as $fee) {
                $itemStmt->execute([$invoiceId, $fee['category_id'], $fee['amount'], $fee['description']]);
            }
            $count++;
        }
        return $count;
    }
    
    public function getStudentInvoices($studentId) {
        return $this->select("
            SELECT fi.*, t.name as term_name, ay.name as year_name
            FROM fee_invoices fi
            JOIN terms t ON fi.term_id = t.id
            JOIN academic_years ay ON t.academic_year_id = ay.id
            WHERE fi.student_id = $studentId
            ORDER BY fi.created_at DESC
        ");
    }
    
    public function getDefaulters($termId) {
        return $this->select("
            SELECT s.first_name, s.last_name, s.student_id, fi.total_amount, fi.paid_amount, (fi.total_amount - fi.paid_amount) as balance
            FROM fee_invoices fi
            JOIN students s ON fi.student_id = s.id
            WHERE fi.term_id = $termId AND fi.status != 'paid'
            ORDER BY balance DESC
        ");
    }
}
